# PokéHub — Collectible Locator

A fan-made, multi-page front-end for tracking Pokémon collectibles: rare spawns, TCG pricing, a marketplace, a GO companion, and a wishlist/trade network.

## Pages
- `index.html` — home, search, and links into every section
- `locator.html` — rare nearby spawns with filters
- `trade.html` — marketplace with live pricing and seller chat
- `tcg.html` — card scanner, collection value, and a pricing table
- `go.html` — live raids, spawn radar, events, raid matchmaking
- `wishlist.html` — wishlist and matching nearby traders

## Files
- `style.css` — shared styling
- `app.js` — shared data + logic (search, chat, ads, rendering)

## Deploying to GitHub Pages
1. Create a new repo (or reuse `PokeLink`) and add these files to the root.
2. Commit and push to the `main` branch.
3. In the repo's **Settings → Pages**, set the source to `main` / `/ (root)`.
4. Your site will be live at `https://<username>.github.io/<repo>/` within a few minutes.

All data (listings, prices, chat, raids) is mock/demo data generated client-side — nothing is fetched from a real server. The sidebar ad units are demo placeholders and don't link anywhere real.

Not affiliated with Nintendo, Game Freak, or The Pokémon Company.
